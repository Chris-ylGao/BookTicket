import java.util.*;
import java.io.*;
import java.util.HashMap;
import java.lang.*;
import java.sql.Timestamp;
/**
 * Write a description of class Office here.
 *
 * @author YANLIN GAO
 * @version 2019/1/28
 */
public class Office
{
    private static PrintWriter outFile;
    private static SortedArrayList<Event> events; //store the information of event of given file
    private static SortedArrayList<Client> clients;// store the information of clients of given file
    private static String inputFirstname; // store the first name inputting from keyboard
    private static String inputSurname; // store surname inputting from keyboard
    private static String inputEvent;// store the name of event inputting from keyboard
    private static int eventId; // store the index of given event in the lsit
    private static int clientId; // store the index of given client in the list
    public Office(){
        // initializing all field variable
           inputFirstname = "";
           inputSurname = "";
           inputEvent = "";
           eventId = -1;
           clientId = -1;
    }
    public static void main(String[] args) throws FileNotFoundException {
       Office o = new Office();
       Scanner sc = new Scanner(System.in);
       outFile = new PrintWriter("/Users/gyl/Desktop/output_file.txt");
       try{
       readFile();
       }catch(Exception e){
         System.out.println(e);
       }
       String option = "";
       boolean end = false;
       while(!end){
           printMenu();
           option = sc.nextLine();
       switch (option){
           case "f": 
           end = true;
           try{
           writeFile(outFile);
          }catch (Exception e){
            System.out.println(e);
          }
           System.exit(0);
           break;
           case "e": printList(events);
           break;
           case "c": printList(clients);
           break;
           case "b": 
           try{
               bookTicket();
            }catch (TicketNotEnoughException e){
                System.out.println("Order decline. Please check the reminder.");
            }
           break;
           case "r": cancelTicket();
           break;
           default: System.out.println("Invalid entry, try again");
        }
    }
    }
    /**
     * print menu;
     */
    public static void printMenu(){
        System.out.println("--------------------------------------------------------------------------------------");
        System.out.println("MENU");
        System.out.println("f - to finish running the program;");
        System.out.println("e - to display on the screen the information about all the events;");
        System.out.println("c - to display on the screen the information about all the clients;");
        System.out.println("b - to update the stored data when tickets are bought by one of the registered clients;");
        System.out.println("r - to update the stored data when a registered client cancels/returns tickets;");
        System.out.println("--------------------------------------------------------------------------------------");
        System.out.println("Type a letter and press Enter");
    }
    /**
     * read file line by line;
     * and store information to SortedArrayList events and clients respectively;
     */
    public static void readFile() throws FileNotFoundException{
        Scanner inFile = new Scanner(new FileReader("/Users/gyl/Desktop/input_file.txt"));
        String input = "";
        //read the information of event;
        int eventNumber = Integer.parseInt(inFile.nextLine());
        events = new SortedArrayList<Event>();
        clients = new SortedArrayList<Client>();
           for (int i = 0; i < eventNumber; i++){
            String name = inFile.nextLine();
            int unsoldTicket = Integer.parseInt(inFile.nextLine());
            events.insert(new Event(name, unsoldTicket));
        }
       //reaad the information of client;
        int clientNumber = Integer.parseInt(inFile.nextLine());
        for (int j =0; j < clientNumber; j++){
            String name = inFile.nextLine();
            clients.insert(new Client(name));
        }
    }
    /**
     * write and save the updated event and client information;
     */
    public static void writeFile(PrintWriter outFile) throws FileNotFoundException{
        outFile.println();
        outFile.println();
        for(Event e : events){
            outFile.println(e);
        }
        for (Client c : clients){
        outFile.println(c);
        }
        outFile.close();
    }

    /**
     * book ticket:
     * if there is no available ticket or the client has booked three events already, then order would be declined
     * if not, the order detail would be add to specified client
     *
     * @throws TicketNotEnoughException
     */
    public static void bookTicket() throws TicketNotEnoughException{
        // check if the client is valid
        readAndCheckName();
        if (clientId != -1){
        // check if the event is valid
        System.out.println("Enter the name of event that you want to book, and press Enter;");
        readAndCheckEvent();
        if(eventId != -1){
            //book the ticket

            if (events.get(eventId).isAvailable() == 0){
                sendReminder(outFile, 0);
                throw new TicketNotEnoughException();
            }else if (clients.get(clientId).getOrder().size() == 3 && !clients.get(clientId).getOrder().containsKey(inputEvent)){
                System.out.println("Sorry, " + inputFirstname + " " + inputSurname + " has book three events.");
                clientId = -1;
            }else{

                boolean valid  = false;
                int soldTicket = 0;

                while(!valid){
                    try{
            Scanner k = new Scanner(System.in);
            System.out.println("Please input the number of tickets you want to book;");
            soldTicket = k.nextInt();
            valid = true;
            if (soldTicket > events.get(eventId).isAvailable()){
                sendReminder(outFile, 1);
                throw new TicketNotEnoughException();
            }
            // if the client has booked this event before, then add the number of tickets;
            // if not, add a new order record;
           if (clients.get(clientId).getOrder().containsKey(inputEvent)){
                Object value = clients.get(clientId).getOrder().get(inputEvent);
                clients.get(clientId).getOrder().put(inputEvent, (int)value + soldTicket);
         }else{
            clients.get(clientId).getOrder().put(inputEvent, soldTicket);
         }
         events.get(eventId).updateUnsoldTicket(events.get(eventId).isAvailable() - soldTicket);
        System.out.println(inputFirstname + " " + inputSurname + " booked " + soldTicket + " tickets of " + inputEvent + " successfully!");
         }catch (NumberFormatException e){
            System.out.println("Invalid input.");
         }
        }
       
        }
        }
        }
     }
     /**
      * cancel ticket:
      * 1. if the client is not a regitered member, or hasn't book any ticket, or enter the wrong event name,
      * then he/she cannot operate this method;
      * 2. if the client has booked this event, but entered a number greater than the number of tickets he/or she has ordered,
      * then this operation cannot be done;
      * 3. only if the client input correct information, then he/she can return the ticket or cancel the total order;
      */
    public static void cancelTicket(){
        readAndCheckName();
        if (clientId != -1) {
        if (clients.get(clientId).getOrder().isEmpty()){
            System.out.println("Sorry, " + inputFirstname + " " + inputSurname + " has not booked any ticket yet");
        }else{
            System.out.println("Enter the name of event that you want to cancel, and press Enter;");
        readAndCheckEvent();
        if (eventId != -1){
            if (clients.get(clientId).getOrder().containsKey(inputEvent)){
                boolean end = false;
                int num = 0;
                while (!end){
                try{
                System.out.println("Please input the number of tickets you want to cancel");
                Scanner sc = new Scanner(System.in);
                num = sc.nextInt();
                end =true;
                }catch(Exception e){
                    System.out.println("Invalid input.");
                }
                 }
                
                int result = clients.get(clientId).updateOrder(inputEvent, num);
                if (result< 0){
                    System.out.println("Order declined, since " + inputFirstname + " " + inputSurname + " hasn't booked " + num + " tickets");
                }else if (result == 0){
                    System.out.println(inputFirstname + " " + inputSurname + " has removed the oroder of " + inputEvent + ".");
                    events.get(eventId).updateUnsoldTicket(events.get(eventId).isAvailable() + num);
                }else{
                    System.out.println(inputFirstname + " " + inputSurname + "has removed " + num + " ticket of " + inputEvent + ".");
                    events.get(eventId).updateUnsoldTicket(events.get(eventId).isAvailable() + num);
                }
                    
                
            }else{
                System.out.println(inputFirstname + " " + inputSurname + " has not booked ticket of " + inputEvent);
            }
        }
    }
      }
    }

    /**
     * get the name of client from keyboard
     * and check whether the client is registered client.
     */
    public static void readAndCheckName(){
        inputFirstname = "";
        inputSurname = "";
        clientId = -1;
        System.out.println("Enter person's firstname and surname respectively, and press Enter;");
        Scanner in = new Scanner(System.in);
        inputFirstname = in.nextLine();
        inputSurname = in.nextLine();
        for (int i = 0; i < clients.size(); i++){
            Client c  = clients.get(i);
            if (c.checkName(inputFirstname, inputSurname) == true) clientId = i;
        }
        if (clientId == -1){
            System.out.println(inputFirstname + " " + inputSurname + " is not registered client.");
            System.out.println("Please check and enter again");
        } 
    }

    /**
     * get the name of event from keyboard
     * and check whether the event is in the list of available events.
     */
     public static void readAndCheckEvent(){
        inputEvent = "";
        eventId = -1;
        
        Scanner in = new Scanner(System.in);
        inputEvent = in.nextLine();
        for (int i = 0; i < events.size(); i++){
            Event e  = events.get(i);
            if (e.checkName(inputEvent) == true) eventId = i;
        }
        if (eventId == -1){
            System.out.println(inputEvent + " is not on the list of available events;");
            System.out.println("Please check and enter again");
        }
    }
    /**
     * print note to a file informing the client that the tickets are not available;
     */
    public static void sendReminder(PrintWriter f, int i){
        f.println(new Date());
        f.print(inputFirstname + " " + inputSurname + " failed to book ticket of " + inputEvent + ", ");
        if (i == 0){
            f.print("since all the tickets of " + inputEvent + " are sold out.");
        }
        if (i == 1){
        if (i == 1){
            f.print("since there is no enough tickets of " + inputEvent + ".");
        }
    }
}
    /**
     * print all the elements in the list
     */
    public static void printList(Iterable<?> list){
    for (Object element : list) {
        System.out.println(element);
    }

}
}


