import java.util.*;
import java.lang.*;
/**
 * Client object
 * to store and retrieve information of client
 *
 * @author YANLIN GAO
 * @version 2019/11/28
 */
public class Client implements Comparable<Client>
{
    private String firstName;  // store the first name of client
    private String surname;  // store surname of client
    private HashMap<String, Integer> ticket; // store the ordering information of client
    
    public Client(String inputName){
        // initializing Client object by paramater name and providing an empty HashMsp
        String[] name = inputName.split(" ");
        firstName = name[0];
        surname= name[1];
        ticket = new HashMap<String, Integer>();
    }

    /**
     * Method to check if the client is a registered client
     * return true only if the given name are equal to both first name and surname of client
     * @param firstname
     * @param surname
     * @return  boolean
     */
    public boolean checkName(String firstname, String surname){
        return this.firstName.equals(firstname) && this.surname.equals(surname);
    }

    /**
     * Method to get the order of client
     * @return HashMap
     */
    public HashMap getOrder(){
        return ticket;
    }

    /**
     * Method to update order
     * @param e the name of event name
     * @param num the number that client booked
     * @return newValue
     */
    public int updateOrder(String e, int num){
        int newValue = 0;
        String key = "";
        if (ticket.containsKey(e)) key = e;
        newValue  = ticket.get(key) - num;
                if (newValue == 0) ticket.remove(key);
                if (newValue > 0) ticket.put(key,newValue);
        return newValue;
    }

    /**
     * instantiate compareTo method
     *
     * comparing to the surname first.
     * if two clients have same surname, then comparing to first name;
     * Assuming that there is no two clients with same surname and firstName;
     * @param c
     * @return
     */
    public int compareTo(Client c){

        int surCmp = surname.compareTo(c.surname);
        if (surCmp != 0) {
            return surCmp;
        }else{
            int fnCmp = firstName.compareTo(c.firstName);
            return fnCmp;
        }
    }
    /**
     * overwrite toString() method
     * to print the detail of client
     * if the client hasn't ordered any ticket, then only print the name of client;
     * or print the detail of order followed by name;
     * @return
     */
    public String toString(){
        if (ticket.isEmpty()) return firstName + " " + surname;
        String output ="{";
        for (String i : ticket.keySet()) {
            output += "(" + i + ", " + ticket.get(i) + "), ";
        }
        output = output.substring(0, output.length() - 2);
        output += "}";
        return firstName + " " + surname + ", " + output;
    }
}
