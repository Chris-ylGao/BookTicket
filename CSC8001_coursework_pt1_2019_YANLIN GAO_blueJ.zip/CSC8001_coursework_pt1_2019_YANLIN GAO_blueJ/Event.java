import java.lang.*;
import java.util.*;
/**
 * Evetnt Object
 * to store and retrieve information of event
 *
 * @author YANLIN GAO
 * @version 2019/11/28
 */
public class Event implements Comparable<Event>
{
    private String name;  //store the name of event;
    private int unsoldTicket; //store the number of available tickets
    public Event(String name, int unsoldTicket){
    // initializing Event object by parameter name and unsolidTicket;
    this.name = name;
    if (unsoldTicket <0) throw new IllegalArgumentException();
    this.unsoldTicket = unsoldTicket;
    }
    /**
     * check whether the name of event is equal to input string;
     * @param String s, the input string
     * @return boolean
     */
    public boolean checkName(String s){
        if (name.equals(s)) return true;
        return false;
    }
    
    /**
     * check the the number of unsoldTicket
     * @return int unsoldTicket
     */
    public int isAvailable(){
        return unsoldTicket;
    }
    /**
     * update the number of available tickets
     */
    public void updateUnsoldTicket(int ticket){
        unsoldTicket = ticket;
    }
    /**
     * instantiate compareTo method
     * odering the Event object by name;
     * Assuming that all events have unique name;
     */
    public int compareTo (Event e) {
        int nameCmp = name.compareTo(e.name);
        return nameCmp;
    }

    /**
     * overwrite toString() method
     * to print the detail of event in format "EventName(maximum length 20)"(left align)
     * and "AvailableTickets(maximum length 10)" (right align);
     * @return
     */
    public String toString(){
        String s = String.format("%-20s%10d", name, unsoldTicket);
        return s;
    }

}
