import java.util.*;
import java.util.*;
/**
 * Write a description of class SortedArrayList here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SortedArrayList<E extends Comparable<? super E>> extends ArrayList<E>
{
    public void insert(E e){
        if (size() == 0) {
            add(e);
        }else{
        int i = 0;
        while (i < size()){
            E current = get(i);
            if (current.compareTo(e) > 0){
                add(i,e);
                break;
            }else{
                i ++;
            }
        }
        if (i == size()) add(e);
    }
    }
}
