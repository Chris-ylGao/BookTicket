public class TicketNotEnoughException extends Exception{
    public  TicketNotEnoughException(){
        super();
        
    }
    
    }
